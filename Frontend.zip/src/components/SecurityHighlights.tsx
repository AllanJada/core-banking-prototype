import { Stack, Typography, Box } from "@mui/material";
import type { SvgIconComponent } from "@mui/icons-material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import SwapHorizOutlinedIcon from "@mui/icons-material/SwapHorizOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";

interface Highlight {
  icon: SvgIconComponent;
  text: string;
}

// Phrased to describe what the system actually does today, not aspirational
// compliance claims it hasn't earned yet.
const HIGHLIGHTS: Highlight[] = [
  { icon: SwapHorizOutlinedIcon, text: "Direct file exchange between institutions" },
  { icon: LockOutlinedIcon, text: "Passwords hashed, never stored in plain text" },
  { icon: VisibilityOutlinedIcon, text: "Full visibility into every transfer's status" },
];

// Same readability workaround as LoginPage: a dark halo behind text/icons,
// independent of whatever frost level the parent panel is set to.
const textShadowSx = {
  textShadow: "0 1px 3px rgba(0,0,0,0.65), 0 1px 8px rgba(0,0,0,0.4)",
};

export default function SecurityHighlights() {
  return (
    <Stack spacing={2}>
      {HIGHLIGHTS.map(({ icon: Icon, text }) => (
        <Stack key={text} direction="row" spacing={1.5} sx={{ alignItems: "center" }}>
          <Box
            sx={{
              width: 32,
              height: 32,
              flexShrink: 0,
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              // Solid dark backing (not glass — just a plain translucent-black
              // circle) so the icon reads clearly regardless of the parent
              // panel's frost setting.
              background: "rgba(0,0,0,0.35)",
              boxShadow: "0 1px 4px rgba(0,0,0,0.4)",
            }}
          >
            <Icon sx={{ color: "#fff", fontSize: 18 }} />
          </Box>
          <Typography variant="body2" sx={{ color: "rgba(255,255,255,0.9)", ...textShadowSx }}>
            {text}
          </Typography>
        </Stack>
      ))}
    </Stack>
  );
}
